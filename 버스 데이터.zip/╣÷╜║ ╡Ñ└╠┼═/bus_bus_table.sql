-- MySQL dump 10.13  Distrib 8.0.25, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: bus
-- ------------------------------------------------------
-- Server version	8.0.25

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `bus_table`
--

DROP TABLE IF EXISTS `bus_table`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bus_table` (
  `start` char(20) DEFAULT NULL,
  `end` char(20) DEFAULT NULL,
  `starttime` char(20) DEFAULT NULL,
  `company` char(20) DEFAULT NULL,
  `class` char(20) DEFAULT NULL,
  `seats` char(20) DEFAULT NULL,
  `price` char(20) DEFAULT NULL,
  `date` char(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bus_table`
--

LOCK TABLES `bus_table` WRITE;
/*!40000 ALTER TABLE `bus_table` DISABLE KEYS */;
INSERT INTO `bus_table` VALUES ('인천','서울','08:00','인천고속','우등','25','9400','2021-10-01'),('인천','서울','09:00','인천고속','우등','24','9400','2021-10-01'),('인천','서울','10:00','인천고속','우등','25','9400','2021-10-01'),('인천','서울','11:00','인천고속','우등','24','9400','2021-10-01'),('인천','서울','12:00','인천고속','우등','25','9400','2021-10-01'),('인천','서울','13:00','인천고속','우등','25','9400','2021-10-01'),('인천','서울','14:00','인천고속','우등','25','9400','2021-10-01'),('인천','서울','15:00','인천고속','우등','25','9400','2021-10-01'),('인천','서울','16:00','인천고속','우등','25','9400','2021-10-01'),('인천','서울','17:00','인천고속','우등','25','9400','2021-10-01'),('인천','서울','18:00','인천고속','우등','25','9400','2021-10-01'),('군산','서울','08:00','전북고속','우등','25','9400','2021-10-01'),('군산','서울','09:00','전북고속','우등','25','9400','2021-10-01'),('군산','서울','10:00','전북고속','우등','25','9400','2021-10-01'),('군산','서울','11:00','전북고속','우등','25','9400','2021-10-01'),('군산','서울','12:00','전북고속','우등','25','9400','2021-10-01'),('군산','서울','13:00','전북고속','우등','25','9400','2021-10-01'),('군산','서울','14:00','전북고속','우등','25','9400','2021-10-01'),('군산','서울','15:00','전북고속','우등','25','9400','2021-10-01'),('군산','서울','16:00','전북고속','우등','25','9400','2021-10-01'),('군산','서울','17:00','전북고속','우등','25','9400','2021-10-01'),('군산','서울','18:00','전북고속','우등','25','9400','2021-10-01');
/*!40000 ALTER TABLE `bus_table` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-12-16 17:28:32
